Necessary styles:
  -- ifpdf.sty
  -- cite.sty
  -- url.sty
  -- HYPERREF Package

You might visit the official sources at http://www.dante.de/cgi-bin/ctan-index

Please make sure your installation has the latest version of the
packages URL and HYPERREF.

For questions concerning the Eurographics Style please contact publishing@eg.org

